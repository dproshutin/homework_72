import React, {Component} from 'react';
import './Orders.css';

class Orders extends Component {
    render() {
        return (
            <div>Orders to be here</div>
        );
    }
}

export default Orders;